﻿////////////////////////////////////////////////////////////////////////////
// NavigatorServer.cs - File Server for WPF NavigatorClient Application   //
// ver 2.0                                                                //
// Jim Fawcett, CSE681 - Software Modeling and Analysis, Fall 2017        //
////////////////////////////////////////////////////////////////////////////
/*
 * Package Operations:
 * -------------------
 * This package defines a single NavigatorServer class that returns file
 * and directory information about its rootDirectory subtree.  It uses
 * a message dispatcher that handles processing of all incoming and outgoing
 * messages.
 * 
 * Maintanence History:
 * --------------------
 * ver 2.0 - 24 Oct 2017
 * - added message dispatcher which works very well - see below
 * - added these comments
 * ver 1.0 - 22 Oct 2017
 * - first release
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using MessagePassingComm;

namespace Navigator
{
    public class NavigatorServer
    {
        FileUtilities.IFileMgr localFileMgr { get; set; } = null;
        Comm comm { get; set; } = null;
        string a = "", temp = "";
        string[] str;
        List<string> selectedfiles = new List<string>();

        Dictionary<string, Func<CommMessage, CommMessage>> messageDispatcher =
          new Dictionary<string, Func<CommMessage, CommMessage>>();

        /*----< initialize server processing >-------------------------*/

        public NavigatorServer()
        {
            initializeEnvironment();
            Console.Title = "Navigator Server";
            localFileMgr = FileUtilities.FileMgrFactory.create(FileUtilities.FileMgrType.Local);
        }
        /*----< set Environment properties needed by server >----------*/

        void initializeEnvironment()
        {
            Environment.root = ServerEnvironment.root;
            Environment.address = ServerEnvironment.address;
            Environment.port = ServerEnvironment.port;
            Environment.endPoint = ServerEnvironment.endPoint;
        }
        /*----< define how each message will be processed >------------*/

        void initializeDispatcher()
        {
            Func<CommMessage, CommMessage> getTopFiles = (CommMessage msg) =>
            {
                localFileMgr.currentPath = "";
                CommMessage reply = new CommMessage(CommMessage.MessageType.reply);
                reply.to = msg.from;
                reply.from = msg.to;
                reply.command = "getTopFiles";
                reply.arguments = localFileMgr.getFiles().ToList<string>();
                return reply;
            };
            messageDispatcher["getTopFiles"] = getTopFiles;

            Func<CommMessage, CommMessage> getTopDirs = (CommMessage msg) =>
            {
                localFileMgr.currentPath = "";
                CommMessage reply = new CommMessage(CommMessage.MessageType.reply);
                reply.to = msg.from;
                reply.from = msg.to;
                reply.command = "getTopDirs";
                reply.arguments = localFileMgr.getDirs().ToList<string>();
                return reply;
            };
            messageDispatcher["getTopDirs"] = getTopDirs;

            Func<CommMessage, CommMessage> moveIntoFolderFiles = (CommMessage msg) =>
            {
                if (msg.arguments.Count() == 1)
                    localFileMgr.currentPath = msg.arguments[0];
                CommMessage reply = new CommMessage(CommMessage.MessageType.reply);
                reply.to = msg.from;
                reply.from = msg.to;
                reply.command = "moveIntoFolderFiles";
                reply.arguments = localFileMgr.getFiles().ToList<string>();
                return reply;
            };
            messageDispatcher["moveIntoFolderFiles"] = moveIntoFolderFiles;

            Func<CommMessage, CommMessage> moveIntoFolderDirs = (CommMessage msg) =>
            {

                if (msg.arguments.Count() == 1)
                {
                    localFileMgr.currentPath = msg.arguments[0];
                    string dirName = msg.arguments[0];
                    localFileMgr.pathStack.Push(localFileMgr.currentPath);
                    localFileMgr.currentPath = dirName;
                }
                CommMessage reply = new CommMessage(CommMessage.MessageType.reply);
                reply.to = msg.from;
                reply.from = msg.to;
                reply.command = "moveIntoFolderDirs";
                reply.arguments = localFileMgr.getDirs().ToList<string>();
                return reply;
            };
            messageDispatcher["moveIntoFolderDirs"] = moveIntoFolderDirs;

            Func<CommMessage, CommMessage> updirs = (CommMessage msg) =>
            {
                if (localFileMgr.pathStack.Count != 1)
                {
                    localFileMgr.pathStack.Pop();
                    localFileMgr.currentPath = localFileMgr.pathStack.Peek();
                }
                else
                {
                    localFileMgr.currentPath = "";
                }
                CommMessage reply = new CommMessage(CommMessage.MessageType.reply);
                reply.to = msg.from;
                reply.from = msg.to;
                reply.command = "updirs";
                reply.arguments = localFileMgr.getDirs().ToList<string>();
                return reply;
            };
            messageDispatcher["updirs"] = updirs;

            Func<CommMessage, CommMessage> upfiles = (CommMessage msg) =>
            {
                localFileMgr.currentPath = localFileMgr.pathStack.Peek();
                CommMessage reply = new CommMessage(CommMessage.MessageType.reply);
                reply.to = msg.from;
                reply.from = msg.to;
                reply.command = "upfiles";
                reply.arguments = localFileMgr.getFiles().ToList<string>();
                return reply;
            };
            messageDispatcher["upfiles"] = upfiles;

            Func<CommMessage, CommMessage> addfiles = (CommMessage msg) =>
            {
                List<string> comp = new List<string>();
                CommMessage reply = new CommMessage(CommMessage.MessageType.reply);
                reply.to = msg.from;
                reply.from = msg.to;
                reply.command = "addfiles";
                string ex = Path.GetExtension(msg.arguments[0]);
                if (ex == ".cs")
                {
                    if (!selectedfiles.Contains(msg.arguments[0]))
                    {
                        reply.arguments.Add( msg.arguments[0]);
                        selectedfiles.Add(msg.arguments[0]);
                    }
                }
                return reply;
            };
            messageDispatcher["addfiles"] = addfiles;

            Func<CommMessage, CommMessage> removefiles = (CommMessage msg) =>
            {
                for(int i = 0; i < selectedfiles.Count; ++i)
                {
                    if (selectedfiles[i] == msg.arguments[0]) {
                        selectedfiles.Remove(selectedfiles[i]);
                        break;
                    }
                }
                CommMessage reply = new CommMessage(CommMessage.MessageType.reply);
                reply.to = msg.from;
                reply.from = msg.to;
                reply.command = "removefiles";
                foreach (var a in selectedfiles)
                {
                    reply.arguments.Add(a);
                }
                return reply;
            };
            messageDispatcher["removefiles"] = removefiles;

            Func<CommMessage, CommMessage> clear = (CommMessage msg) =>
            {
                CommMessage reply = new CommMessage(CommMessage.MessageType.reply);
                reply.to = msg.from;
                reply.from = msg.to;
                reply.command = "removefiles";
                reply.arguments.Clear();
                selectedfiles.Clear();
                return reply;
            };
            messageDispatcher["clear"] = clear;

            Func<CommMessage, CommMessage> selectfiles = (CommMessage msg) =>
            {
                List<string> comp = new List<string>();
                if (msg.arguments.Count() != 0)
                    a = msg.arguments[0];
                str = a.Split('\\');
                temp = str[str.Length - 1];
                if (temp != str[0])
                {
                    a = a.Substring(0, a.Length - temp.Length - 1);
                    localFileMgr.currentPath = a;
                }
                else localFileMgr.currentPath = "";
                CommMessage reply = new CommMessage(CommMessage.MessageType.reply);
                reply.to = msg.from;
                reply.from = msg.to;
                reply.command = "selectfiles";
                comp = localFileMgr.getcsFiles().ToList<string>();
                foreach(var i in comp)
                {
                    if(!selectedfiles.Contains(i))
                    {
                        reply.arguments.Add(i);
                        selectedfiles.Add(i);
                    }
                }
                return reply;
            };
            messageDispatcher["selectfiles"] = selectfiles;

            Func<CommMessage, CommMessage> addallfiles = (CommMessage msg) =>
            {
                
                List<string> filesname = new List<string>();
                FileUtilities.Navigate navigate = new FileUtilities.Navigate();
                localFileMgr.currentPath = msg.arguments[0];
                string path;
                path = Path.GetFullPath(Environment.root);
                navigate.FindFile(path);
                filesname = navigate.FindFile(path);
                CommMessage reply = new CommMessage(CommMessage.MessageType.reply);
                reply.to = msg.from;
                reply.from = msg.to;
                reply.command = "addallfiles";
                foreach(var i in filesname)
                {
                    if (!selectedfiles.Contains(i))
                    {
                        reply.arguments.Add(i);
                        selectedfiles.Add(i);
                    }
                }
                return reply;
                
            };
            messageDispatcher["addallfiles"] = addallfiles;

            Func<CommMessage, CommMessage> typetable = (CommMessage msg) =>
            {
                CommMessage reply = new CommMessage(CommMessage.MessageType.reply);
                reply.to = msg.from;
                reply.from = msg.to;
                reply.command = "typetable";
                TypeTable.TypeTable types = new TypeTable.TypeTable();
                types = Tester.server_test.run_typetable(msg.arguments.ToArray());
                reply.arguments = types.print();          
                return reply;
            };
            messageDispatcher["typetable"] = typetable;

            Func<CommMessage, CommMessage> depanalysis = (CommMessage msg) =>
            {
                CommMessage reply = new CommMessage(CommMessage.MessageType.reply);
                reply.to = msg.from;
                reply.from = msg.to;
                reply.command = "depanalysis";
                DepAnalysis.DAnalysiss ana = new DepAnalysis.DAnalysiss();
                ana = Tester.server_test.run_depanalysis(msg.arguments.ToArray());
                foreach(var i in ana.print())
                {
                    if (!reply.arguments.Contains(i))
                        reply.arguments.Add(i);
                }
                return reply;
            };
            messageDispatcher["depanalysis"] = depanalysis;

            Func<CommMessage, CommMessage> strongcomponent = (CommMessage msg) =>
            {
                CommMessage reply = new CommMessage(CommMessage.MessageType.reply);
                reply.to = msg.from;
                reply.from = msg.to;
                reply.command = "strongcomponent";
                List<string> SClist = new List<string>();
                SClist = Tester.server_test.run_strongcomponent(msg.arguments.ToArray());
                foreach(var s in msg.arguments)
                {
                    string b = Path.GetFileName(Path.Combine(Navigator.Environment.root, s));
                    foreach(var k in SClist)
                    {
                        if (k.Contains(b))
                        {
                            if(! reply.arguments.Contains(k))
                                reply.arguments.Add(k);
                        }
                    }
                }
                return reply;
            };
            messageDispatcher["strongcomponent"] = strongcomponent;

        }
        /*----< Server processing >------------------------------------*/
        /*
         * - all server processing is implemented with the simple loop, below,
         *   and the message dispatcher lambdas defined above.
         */
        static void Main(string[] args)
        {
            TestUtilities.title("Starting Navigation Server", '=');
            try
            {
                NavigatorServer server = new NavigatorServer();
                server.initializeDispatcher();
                server.comm = new MessagePassingComm.Comm(ServerEnvironment.address, ServerEnvironment.port);

                while (true)
                {                 
                    /*
                    CommMessage msg1 = new CommMessage(CommMessage.MessageType.request);
                    msg1.from = ClientEnvironment.endPoint;
                    msg1.to = ServerEnvironment.endPoint;
                    msg1.command = "strongcomponent";
                    string item = "";//\\TestB\\App.xaml.cs";
                    msg1.arguments.Add(item);
                    server.comm.postMessage(msg1);
                    */
                    CommMessage msg = server.comm.getMessage();
                    if (msg.type == CommMessage.MessageType.closeReceiver)
                        break;
                    msg.show();
                    if (msg.command == null)
                        continue;
                    CommMessage reply = server.messageDispatcher[msg.command](msg);
                    reply.show();
                    server.comm.postMessage(reply);
                }
            }
            catch (Exception ex)
            {
                Console.Write("\n  exception thrown:\n{0}\n\n", ex.Message);
            }
        }
    }
}
