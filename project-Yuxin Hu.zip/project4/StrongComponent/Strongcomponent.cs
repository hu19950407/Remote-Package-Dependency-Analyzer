﻿///////////////////////////////////////////////////////////////////////
// CsGraph.cs - Generic node and directed graph classes              //
// Language:    C#, 2008, .Net Framework 4.0                         //
// Application: Demonstration for CSE681, Project #3, Fall 2018      //
// Author:      Yuxin Hu, Syracuse University                        //
///////////////////////////////////////////////////////////////////////
/*
 *  * Package Operations
 * ==================
 * This package use tarjana algorithm to  ahieve the Strongcomponent connection between 
 * files that used in this project.
 * In addition, it uses setGraph class to create a graph that used in tarjana algorithm
 * Maintenance History:
 * --------------------
 * ver 1,0 :
 * - first release
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DepAnalysis;

namespace CsGraph
{
    /////////////////////////////////////////////////////////////////////////
    // CsEdge<V,E> and CsNode<V,E> classes

    public class CsEdge<V, E> // holds child node and instance of edge type E
    {
        public CsNode<V, E> targetNode { get; set; } = null;
        public E edgeValue { get; set; }

        public CsEdge(CsNode<V, E> node, E value)
        {
            targetNode = node;
            edgeValue = value;
        }
    };

    public class CsNode<V, E>
    {
        public V nodeValue { get; set; }
        public string name { get; set; }
        public List<CsEdge<V, E>> children { get; set; }
        public bool visited { get; set; }
        public int n1 { get; set; } = -1;
        public int n2 { get; set; } = -1;

        //----< construct a named node >---------------------------------------

        public CsNode(string nodeName)
        {
            name = nodeName;
            children = new List<CsEdge<V, E>>();
            visited = false;
        }
        //----< add child vertex and its associated edge value to vertex >-----

        public void addChild(CsNode<V, E> childNode, E edgeVal)
        {
            children.Add(new CsEdge<V, E>(childNode, edgeVal));
        }
        //----< find the next unvisited child >--------------------------------

        public CsEdge<V, E> getNextUnmarkedChild()
        {
            foreach (CsEdge<V, E> child in children)
            {
                if (!child.targetNode.visited)
                {
                    child.targetNode.visited = true;
                    return child;
                }
            }
            return null;
        }
        //----< has unvisited child? >-----------------------------------

        public bool hasUnmarkedChild()
        {
            foreach (CsEdge<V, E> child in children)
            {
                if (!child.targetNode.visited)
                {
                    return true;
                }
            }
            return false;
        }
        public void unmark()
        {
            visited = false;
        }
        public override string ToString()
        {
            return name;
        }
    }
    /////////////////////////////////////////////////////////////////////////
    // Operation<V,E> class

    class Operation<V, E>
    {
        //----< graph.walk() calls this on every node >------------------------

        virtual public bool doNodeOp(CsNode<V, E> node)
        {
            Console.Write("\n  {0}", node.ToString());
            return true;
        }
        //----< graph calls this on every child visitation >-------------------

        virtual public bool doEdgeOp(E edgeVal)
        {
            Console.Write(" {0}", edgeVal.ToString());
            return true;
        }
    }
    /////////////////////////////////////////////////////////////////////////
    // CsGraph<V,E> class

    class CsGraph<V, E>
    {
        public CsNode<V, E> startNode { get; set; }
        public string name { get; set; }
        public bool showBackTrack { get; set; } = false;
        public List<string> sclist = new List<string>();


        private List<CsNode<V, E>> adjList { get; set; }  // node adjacency list
        private Operation<V, E> gop = null;

        public static int dfn_index = 0;
        Stack<CsNode<V, E>> stock = new Stack<CsNode<V, E>>();
        //----< construct a named graph >--------------------------------------

        public CsGraph(string graphName)
        {
            name = graphName;
            adjList = new List<CsNode<V, E>>();
            gop = new Operation<V, E>();
            startNode = null;
        }
        //----< register an Operation with the graph >-------------------------

        public Operation<V, E> setOperation(Operation<V, E> newOp)
        {
            Operation<V, E> temp = gop;
            gop = newOp;
            return temp;
        }
        //----< add vertex to graph adjacency list >---------------------------

        public void addNode(CsNode<V, E> node)
        {
            adjList.Add(node);
        }
        //----< clear visitation marks to prepare for next walk >--------------

        public void clearMarks()
        {
            foreach (CsNode<V, E> node in adjList)
                node.unmark();
        }
        //----< depth first search from startNode >----------------------------

        public void walk()
        {
            if (adjList.Count == 0)
            {
                Console.Write("\n  no nodes in graph");
                return;
            }
            if (startNode == null)
            {
                Console.Write("\n  no starting node defined");
                return;
            }
            if (gop == null)
            {
                Console.Write("\n  no node or edge operation defined");
                return;
            }
            this.walk(startNode);
            foreach (CsNode<V, E> node in adjList)
                if (!node.visited)
                    walk(node);
            foreach (CsNode<V, E> node in adjList)
                node.unmark();
            return;
        }
        //----< depth first search from specific node >------------------------

        public void walk(CsNode<V, E> node)
        {
            // process this node

            gop.doNodeOp(node);
            node.visited = true;

            // visit children
            do
            {
                CsEdge<V, E> childEdge = node.getNextUnmarkedChild();
                if (childEdge == null)
                {
                    return;
                }
                else
                {
                    gop.doEdgeOp(childEdge.edgeValue);
                    walk(childEdge.targetNode);
                    if (node.hasUnmarkedChild() || showBackTrack)
                    {                         // popped back to predecessor node
                        gop.doNodeOp(node);     // more edges to visit so announce
                    }                         // location and next edge
                }
            } while (true);
        }

        public List<string> tarjan(CsNode<V, E> node)
        {
            node.n1 = node.n2 = ++dfn_index;                   
            stock.Push(node);                       
            foreach (var a in node.children)
            {
                if (a.targetNode.n1 < 0)
                {
                    tarjan(a.targetNode);           
                    node.n2 = Math.Min(a.targetNode.n2, node.n2);
                }
                else if (stock.Contains(a.targetNode))                
                node.n2 = Math.Min(node.n2, a.targetNode.n1);
            }
            if (node.n1 == node.n2)
            {
                Console.Write("\n  StrongComponent: ");
                sclist.Add("StrongComponent: ");
                CsNode<V, E> w;
                do
                {
                    w = stock.Pop();
                    Console.Write(w.name + " ");
                    sclist.Add(w.name);
                } while (w != node);
                Console.Write("\n");
            }
            return sclist;
            //         Console.WriteLine();
        }
        public List<string> tarjan()
        {
            List<string> temp = new List<string>();
            foreach (var v in adjList)
            {
                if (v.n1 < 0)
                {
                    foreach(var a in tarjan(v))
                    {
                        temp.Add(a);
                    }
                }
            }
            return temp;
            //         Console.WriteLine();
        }

        public void showDependencies()
        {
            Console.Write("\n");
            Console.Write("\n");
            Console.Write("\n");
            Console.Write("\n  Dependency Table (Graph):");
            Console.Write("\n =========================================");
            foreach (var node in adjList)
            {
                if (node.children.Count != 0)
                {
                    Console.Write("\n  {0}", node.name);
                    Console.Write(" depends on :");
                    for (int i = 0; i < node.children.Count; ++i)
                    {
                        Console.Write("\n     {0}", node.children[i].targetNode.name);
                    }
                    Console.Write("\n");
                }
            }
            Console.Write("\n =========================================");
            Console.Write("\n");
            Console.Write("\n");
            Console.Write("\n");
        }
    }
    public class setGraph
    {
        public List<string> createGraph(DAnalysiss test)
        {
            CsGraph<string, string> dep_graph = new CsGraph<string, string>("graph_name");
            CsNode<string, string> graph_start_node = new CsNode<string, string>("start");
            List<CsNode<string, string>> savenodes = new List<CsNode<string, string>>();
            List<string> recSC = new List<string>();
            List<string> filenames = new List<string>();       // create a new List to store father nodes
            foreach (var ele in test.filecontainer)
            {
                if (filenames.Contains(ele.Key))
                {
                    foreach (var ala in ele.Value)
                    {
                        if (filenames.Contains(ala)) continue;
                        filenames.Add(ala);
                    }
                }
                else filenames.Add(ele.Key);  
                foreach(var ala in ele.Value)
                {
                    if (filenames.Contains(ala)) continue;
                    filenames.Add(ala);
                }
            }
            for(int i = 0; i <filenames.Count; ++i)
            {
                CsNode<string, string> nodes = new CsNode<string, string>(filenames[i]);
                savenodes.Add(nodes);
            }
            foreach (var ele in test.filecontainer)
            {
                foreach (var ls in savenodes)
                {
                    if (ls.name == ele.Key)
                    {
                        foreach (var item in ele.Value)
                        {
                            foreach (var ls2 in savenodes)
                            {
                                if (ls2.name == item)
                                {
                                    ls.addChild(ls2, "EDGE");
                                }
                            }
                        }
                    }
                }

            }
            foreach (var ls in savenodes)
            dep_graph.addNode(ls);
            dep_graph.showDependencies();
            dep_graph.startNode = graph_start_node;
            recSC = dep_graph.tarjan();
            return recSC;
        }
    }
    /////////////////////////////////////////////////////////////////////////
    // Test class

    class demoOperation : Operation<string, string>
    {
        override public bool doNodeOp(CsNode<string, string> node)
        {
            Console.Write("\n -- {0}", node.name);
            return true;
        }
    }
    class Test
    {
        static void Main(string[] args)
        {
            Console.Write("\n  Testing CsGraph class");
            Console.Write("\n =======================");

            CsNode<string, string> node1 = new CsNode<string, string>("node1");
            CsNode<string, string> node2 = new CsNode<string, string>("node2");
            CsNode<string, string> node3 = new CsNode<string, string>("node3");
            CsNode<string, string> node4 = new CsNode<string, string>("node4");
            CsNode<string, string> node5 = new CsNode<string, string>("node5");

            node1.addChild(node2, "edge12");
            node1.addChild(node3, "edge13");
            node2.addChild(node3, "edge23");
            node2.addChild(node4, "edge24");
            node3.addChild(node1, "edge31");
            node5.addChild(node1, "edge51");
            node5.addChild(node4, "edge54");

            CsGraph<string, string> graph = new CsGraph<string, string>("Fred");
            graph.addNode(node1);
            graph.addNode(node2);
            graph.addNode(node3);
            graph.addNode(node4);
            graph.addNode(node5);

            graph.showDependencies();

            graph.startNode = node1;
            Console.Write("\n\n  starting walk at {0}", graph.startNode.name);
            Console.Write("\n  not showing backtracks");
            graph.walk();

            graph.startNode = node2;
            Console.Write("\n\n  starting walk at {0}", graph.startNode.name);
            graph.showBackTrack = true;
            Console.Write("\n  show backtracks");
            graph.setOperation(new demoOperation());
            graph.walk();

            Console.Write("\n\n");
            Console.ReadKey();
        }
    }
}
