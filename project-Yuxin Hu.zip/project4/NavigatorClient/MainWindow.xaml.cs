﻿////////////////////////////////////////////////////////////////////////////
// NavigatorClient.xaml.cs - Demonstrates Directory Navigation in WPF App //
// Language:    C#, 2008, .Net Framework 4.0                              //
// Application: Demonstration for CSE681, Project #3, Fall 2018           //
// Author:      Yuxin Hu, Syracuse University                             //
////////////////////////////////////////////////////////////////////////////
/*
 * Package Operations:
 * -------------------
 * This package defines WPF application processing by the client.  The client
 * displays a local FileFolder view, and a remote FileFolder view.  It supports
 * navigating into subdirectories, both locally and in the remote Server.
 * 
 * It also supports viewing local files.
 * 
 * Maintenance History:
 * --------------------
 * ver 2.1 : 26 Oct 2017
 * - relatively minor modifications to the Comm channel used to send messages
 *   between NavigatorClient and NavigatorServer
 * ver 2.0 : 24 Oct 2017
 * - added remote processing - Up functionality not yet implemented
 *   - defined NavigatorServer
 *   - added the CsCommMessagePassing prototype
 * ver 1.0 : 22 Oct 2017
 * - first release
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using System.Threading;
using MessagePassingComm;

namespace Navigator
{
    public partial class MainWindow : Window
    {
        private FileUtilities.IFileMgr fileMgr { get; set; } = null;  // note: Navigator just uses interface declarations
        Comm comm { get; set; } = null;
        Dictionary<string, Action<CommMessage>> messageDispatcher = new Dictionary<string, Action<CommMessage>>();
        Thread rcvThread = null;

        public MainWindow()
        {
            InitializeComponent();
            initializeEnvironment();
            //Console.Title = "Navigator Client";
            fileMgr = FileUtilities.FileMgrFactory.create(FileUtilities.FileMgrType.Local); // uses Environment
            getTopFiles();
            comm = new Comm(ClientEnvironment.address, ClientEnvironment.port);
            initializeMessageDispatcher();
            rcvThread = new Thread(rcvThreadProc);
            rcvThread.Start();
            CommMessage try_con = new CommMessage(CommMessage.MessageType.connect);
            try_con.from = ClientEnvironment.endPoint;
            try_con.to = ServerEnvironment.endPoint;
            comm.postMessage(try_con);
        }
        //----< make Environment equivalent to ClientEnvironment >-------

        void initializeEnvironment()
        {
            Environment.root = ClientEnvironment.root;
            Environment.address = ClientEnvironment.address;
            Environment.port = ClientEnvironment.port;
            Environment.endPoint = ClientEnvironment.endPoint;
        }
        //----< define how to process each message command >-------------
        void initializeMessageDispatcher()
        {
            // load remoteFiles listbox with files from root
            messageDispatcher["getTopFiles"] = (CommMessage msg) =>
            {
                remoteFiles.Items.Clear();
                foreach (string file in msg.arguments)
                {
                    remoteFiles.Items.Add(file);
                }
            };
            // load remoteDirs listbox with dirs from root
            messageDispatcher["getTopDirs"] = (CommMessage msg) =>
            {
                remoteDirs.Items.Clear();
                foreach (string dir in msg.arguments)
                {
                    remoteDirs.Items.Add(dir);
                }
            };
            // load remoteFiles listbox with files from folder
            messageDispatcher["moveIntoFolderFiles"] = (CommMessage msg) =>
            {
                remoteFiles.Items.Clear();
                foreach (string file in msg.arguments)
                {
                    remoteFiles.Items.Add(file);
                }
            };
            // load remoteDirs listbox with dirs from folder
            messageDispatcher["moveIntoFolderDirs"] = (CommMessage msg) =>
            {
                remoteDirs.Items.Clear();
                foreach (string dir in msg.arguments)
                {
                    remoteDirs.Items.Add(dir);
                }
            };           
            // return to previous dirs
            messageDispatcher["updirs"] = (CommMessage msg) =>
            {
                remoteDirs.Items.Clear();
                foreach (string dir in msg.arguments)
                {
                    remoteDirs.Items.Add(dir);
                }
            };
            // update files in remote files
            messageDispatcher["upfiles"] = (CommMessage msg) =>
            {
                remoteFiles.Items.Clear();
                foreach (string dir in msg.arguments)
                {
                    remoteFiles.Items.Add(dir);
                }
            };
            // add one file from select .cs files interface
            messageDispatcher["addfiles"] = (CommMessage msg) =>
            {
                foreach (string file in msg.arguments)
                {
                    selectedfiles.Items.Add(file);
                }
            };
            // remove one file from select .cs files interface
            messageDispatcher["removefiles"] = (CommMessage msg) =>
            {
                selectedfiles.Items.Clear();
                foreach (string file in msg.arguments)
                {
                    selectedfiles.Items.Add(file);
                }
            };
            // add all .cs files in current dirs to select .cs files interface
            messageDispatcher["selectfiles"] = (CommMessage msg) =>
            {
                foreach (string file in msg.arguments)
                {
                    selectedfiles.Items.Add(file);
                }
            };
            // add all files in current project to select .cs files interface
            messageDispatcher["addallfiles"] = (CommMessage msg) =>
            {
                foreach (string file in msg.arguments)
                {
                    selectedfiles.Items.Add(file);
                }
            };
            // start typetable analysis
            messageDispatcher["typetable"] = (CommMessage msg) =>
            {
                result.Items.Clear();
                foreach (string file in msg.arguments)
                {
                    result.Items.Add(file);
                }
            };
            // start dependency analysis 
            messageDispatcher["depanalysis"] = (CommMessage msg) =>
            {
                result.Items.Clear();
                foreach (string file in msg.arguments)
                {
                    result.Items.Add(file);
                }
            };
            // start strongcomponent analysis
            messageDispatcher["strongcomponent"] = (CommMessage msg) =>
            {
                result.Items.Clear();
                foreach (string file in msg.arguments)
                {
                    result.Items.Add(file);
                }
            };
            //clear all files that show on select .cs files interface
            messageDispatcher["clear"] = (CommMessage msg) =>
            {
                selectedfiles.Items.Clear();
                foreach (string file in msg.arguments)
                {
                    selectedfiles.Items.Add(file);
                }
            };
        }
        //----< define processing for GUI's receive thread >-------------
        void rcvThreadProc()
        {
            Console.Write("\n  starting client's receive thread");
            while (true)
            {
                CommMessage msg = comm.getMessage();
                msg.show();
                if (msg.command == null)
                    continue;
                // pass the Dispatcher's action value to the main thread for execution
                Dispatcher.Invoke(messageDispatcher[msg.command], new object[] { msg });
            }
        }
        //----< shut down comm when the main window closes >-------------
        private void Window_Closed(object sender, EventArgs e)
        {
            comm.close();

            // The step below should not be nessary, but I've apparently caused a closing event to 
            // hang by manually renaming packages instead of getting Visual Studio to rename them.

            System.Diagnostics.Process.GetCurrentProcess().Kill();
        }
        //----< not currently being used >-------------------------------
        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
        }
        //----< show files and dirs in root path >-----------------------
        public void getTopFiles()
        {
            List<string> files = fileMgr.getFiles().ToList<string>();
            localFiles.Items.Clear();
            foreach (string file in files)
            {
                localFiles.Items.Add(file);
            }
            List<string> dirs = fileMgr.getDirs().ToList<string>();
            localDirs.Items.Clear();
            foreach (string dir in dirs)
            {
                localDirs.Items.Add(dir);
            }
        }
        //----< move to directory root and display files and subdirs >---
        private void localTop_Click(object sender, RoutedEventArgs e)
        {
            fileMgr.currentPath = "";
            getTopFiles();
        }
        //----< show selected file in code popup window >----------------
        private void localFiles_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            string fileName = localFiles.SelectedValue as string;
            try
            {
                string path = System.IO.Path.Combine(ClientEnvironment.root, fileName);
                string contents = File.ReadAllText(path);
                CodePopUp popup = new CodePopUp();
                popup.codeView.Text = contents;
                popup.Show();
            }
            catch (Exception ex)
            {
                string msg = ex.Message;
            }
        }
        //----< move to parent directory and show files and subdirs >----
        private void localUp_Click(object sender, RoutedEventArgs e)
        {
            if (fileMgr.currentPath == "")
                return;
            fileMgr.currentPath = fileMgr.pathStack.Peek();
            fileMgr.pathStack.Pop();
            getTopFiles();
        }
        //----< move into subdir and show files and subdirs >------------
        private void localDirs_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            string dirName = localDirs.SelectedValue as string;
            fileMgr.pathStack.Push(fileMgr.currentPath);
            fileMgr.currentPath = dirName;
            getTopFiles();
        }
        //----< move to root of remote directories >---------------------
        /*
         * - sends a message to server to get files from root
         * - recv thread will create an Action<CommMessage> for the UI thread
         *   to invoke to load the remoteFiles listbox
         */
        private void RemoteTop_Click(object sender, RoutedEventArgs e)
        {
            CommMessage msg1 = new CommMessage(CommMessage.MessageType.request);
            msg1.from = ClientEnvironment.endPoint;
            msg1.to = ServerEnvironment.endPoint;
            msg1.author = "";
            msg1.command = "getTopFiles";
            msg1.arguments.Add("");
            comm.postMessage(msg1);
            CommMessage msg2 = msg1.clone();
            msg2.command = "getTopDirs";
            comm.postMessage(msg2);
        }
        //----< download file and display source in popup window >-------
        private void remoteFiles_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            // coming soon
        }
        //----< move to parent directory of current remote path >--------
        private void RemoteUp_Click(object sender, RoutedEventArgs e)
        {
            // coming soon
            CommMessage msg1 = new CommMessage(CommMessage.MessageType.request);
            msg1.from = ClientEnvironment.endPoint;
            msg1.to = ServerEnvironment.endPoint;
            msg1.command = "updirs";
            msg1.arguments.Add("");
            comm.postMessage(msg1);
            CommMessage msg2 = msg1.clone();
            msg2.command = "upfiles";
            comm.postMessage(msg2);
        }
        //----< move into remote subdir and display files and subdirs >--
        /*
         * - sends messages to server to get files and dirs from folder
         * - recv thread will create Action<CommMessage>s for the UI thread
         *   to invoke to load the remoteFiles and remoteDirs listboxs
         */
        private void remoteDirs_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            CommMessage msg1 = new CommMessage(CommMessage.MessageType.request);
            msg1.from = ClientEnvironment.endPoint;
            msg1.to = ServerEnvironment.endPoint;
            msg1.command = "moveIntoFolderFiles";
            msg1.arguments.Add(remoteDirs.SelectedValue as string);
            comm.postMessage(msg1);
            CommMessage msg2 = msg1.clone();
            msg2.command = "moveIntoFolderDirs";
            comm.postMessage(msg2);
        }
        private void Add_Click(object sender, RoutedEventArgs e)
        {
            CommMessage msg1 = new CommMessage(CommMessage.MessageType.request);
            msg1.from = ClientEnvironment.endPoint;
            msg1.to = ServerEnvironment.endPoint;
            msg1.command = "addfiles";
            msg1.arguments.Add(remoteFiles.SelectedValue as string);
            comm.postMessage(msg1);
        }
        private void Remove_Click(object sender, RoutedEventArgs e)
        {
            CommMessage msg1 = new CommMessage(CommMessage.MessageType.request);
            msg1.from = ClientEnvironment.endPoint;
            msg1.to = ServerEnvironment.endPoint;
            msg1.command = "removefiles";
            msg1.arguments.Add(selectedfiles.SelectedValue as string);
            comm.postMessage(msg1);
        }
        private void Select_Click(object sender, RoutedEventArgs e)
        {
            // coming soon
            CommMessage msg1 = new CommMessage(CommMessage.MessageType.request);
            msg1.from = ClientEnvironment.endPoint;
            msg1.to = ServerEnvironment.endPoint;
            msg1.command = "selectfiles";
            foreach (string item in remoteFiles.Items)
            { 
                msg1.arguments.Add(item);
            }
            comm.postMessage(msg1);
        }
        private void AddAll_Click(object sender, RoutedEventArgs e)
        {
            CommMessage msg1 = new CommMessage(CommMessage.MessageType.request);
            msg1.from = ClientEnvironment.endPoint;
            msg1.to = ServerEnvironment.endPoint;
            msg1.command = "addallfiles";
            msg1.arguments.Add("");
            comm.postMessage(msg1);
        }
        private void selectedfiles_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
        }
        private void TypeTable_Click(object sender, RoutedEventArgs e)
        {
            CommMessage msg1 = new CommMessage(CommMessage.MessageType.request);
            msg1.from = ClientEnvironment.endPoint;
            msg1.to = ServerEnvironment.endPoint;
            msg1.command = "typetable";
            foreach (string item in selectedfiles.Items)
            {
                msg1.arguments.Add(item);
            }
            comm.postMessage(msg1);
        }
        private void DepAsis_Click(object sender, RoutedEventArgs e)
        {
            CommMessage msg1 = new CommMessage(CommMessage.MessageType.request);
            msg1.from = ClientEnvironment.endPoint;
            msg1.to = ServerEnvironment.endPoint;
            msg1.command = "depanalysis";
            foreach (string item in selectedfiles.Items)
            {
                msg1.arguments.Add(item);
            }
            comm.postMessage(msg1);
        }
        private void Strong_Click(object sender, RoutedEventArgs e)
        {
            CommMessage msg1 = new CommMessage(CommMessage.MessageType.request);
            msg1.from = ClientEnvironment.endPoint;
            msg1.to = ServerEnvironment.endPoint;
            msg1.command = "strongcomponent";
            foreach (string item in selectedfiles.Items)
            {
                msg1.arguments.Add(item);
            }
            comm.postMessage(msg1);
        }
        private void clear_Click(object sender, RoutedEventArgs e)
        {
            CommMessage msg1 = new CommMessage(CommMessage.MessageType.request);
            msg1.from = ClientEnvironment.endPoint;
            msg1.to = ServerEnvironment.endPoint;
            msg1.command = "clear";
            msg1.arguments.Add("");
            comm.postMessage(msg1);
        }
        private void RemoveUnrelated_Click(object sender, RoutedEventArgs e)
        {
            // coming soon
        }
        private void Selectedfiles_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
        }
    }
}
