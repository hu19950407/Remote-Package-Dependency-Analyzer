﻿///////////////////////////////////////////////////////////////////////
// DAnalysis.cs - Test and Dependency of the project                 //
// Language:    C#, 2008, .Net Framework 4.0                         //
// Application: Demonstration for CSE681, Project #3, Fall 2018      //
// Author:      Yuxin Hu, Syracuse University                        //
///////////////////////////////////////////////////////////////////////
/*
 * Package Operations
 * ==================
 * DepAnalysis manages the relationships between call file and callee files,
 * this package uses Dictionary filecontainer to store file information, its key
 * is the filename of call file and its key.value is the filename of callee file.
 * StrongComponent package uses the information in filecontainer to create a graph
 * that used to produce StrongComponent relationships between all .cs files.
/*
 * Build Process
 * =============
 * Required Files:
 *   TypeTable.cs
 *   ITokenCollections.cs
 *   
 * Maintenance History
 * ===================
 * ver 1.3:
 * - built a show funtion to output dependency relationships table
 * ver 1.2:
 * - solved the duplication of name problem in different files
 * ver 1.1 :
 * - created analysis function
 * ver 1.0 :
 * - first release
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Collections;
using TypeTable;

namespace DepAnalysis
{
    using Callfile = String;
    using Calleefile = List<String>;

    public class DAnalysiss
    {
        public Dictionary<Callfile, Calleefile> filecontainer { get; set; } = new Dictionary<Callfile, Calleefile>();    //----<used to store dependency information>---------------

        public void analysis(Collections.ITokenCollection semi, TypeTable.TypeTable table, String filename)
        {
            foreach (var elem in table.table)       //----<get the information in TypeTable>---------------
            {
                foreach (var item in elem.Value)
                {                 
                    if (semi.contains(item.name))    
                    {
                        if (!semi.contains("interface") && !semi.contains("class") && !semi.contains("struct") && !semi.contains("enum") && !semi.contains("delegate"))
                        {
                            if (filename != item.file)       //----<judge if the current file path equals to the target file path>---------------
                            {
                                if (filecontainer.ContainsKey(filename))
                                {
                                    if (filecontainer[filename].Contains(item.file)) break;
                                    else filecontainer[filename].Add(item.file);            //----<store information>---------------
                                }

                                else
                                {
                                    List<String> temp = new List<String>();
                                    temp.Add(item.file);
                                    filecontainer.Add(filename, temp);           //----<store information>---------------
                                }
                            }
                        }
                       
                    }
            
                }
            }
        }

        public void show()            //----<output the Dependency relationships>---------------
        {
            foreach (String Key in filecontainer.Keys)
            {
                if (filecontainer.Keys.Count == 0) Console.Write("\n  no depedent files");
                Console.Write("\n  The call file : [{0}] ", Key);
                foreach(String value in filecontainer[Key])
                {
                    Console.Write("\n  The callee files : [{0}] ", value);
                }
                Console.Write("\n =========================================");
            }
        }

        public List<string> print()
        {
            List<string> print = new List<string>();
            string temp = "";
            string ttp = "";
            foreach (String Key in filecontainer.Keys)
            {
                temp =  Key + "  depends on :";
                print.Add(temp);
                foreach (String value in filecontainer[Key])
                {
                    ttp += value;
                    ttp += "  ";
                }
                print.Add(ttp);
            }
            return print;
        }

#if (TEST_DEP)
        static void Main(string[] args)
        {
            Console.Write("\n  Tested by use in Test file\n\n");
        }
#endif
    }
}
