﻿///////////////////////////////////////////////////////////////////////
// Parser.cs - Parser detects code constructs defined by rules       //
// Language:    C#, 2008, .Net Framework 4.0                         //
// Application: Demonstration for CSE681, Project #3, Fall 2018      //
// Author:      Yuxin Hu, Syracuse University                        //
///////////////////////////////////////////////////////////////////////
/*
 * Module Operations:
 * ------------------
 * This module defines the following class:
 *   Parser  - a collection of IRules
 *   TestParser  -  initializes the path of file
 */
/* Required Files:
 * parser.cs RulesAndActions.cs Toker.cs ScopeStack.cs Semi.cs IRuleandAction.cs 
 * TypeTable.cs Display.cs ITokenCollection.cs Element.cs
 * Maintenance History:
 * --------------------
 * ver 1.4 :
 *  - made class TestParser, ProcessCommandline, ShowCommandLine a public
 * ver 1.3 :
 *  - modified test stub to display scope counts
 * ver 1.2 :
 * - RulesAndActions were modified to fix bugs reported recently
 * ver 1.1 :
 * - modify the output format of MetricsTable
 * ver 1.0 : 
 * - first release
 */
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using IRuleandActions;
using Collections;
using CodeDisplay;
using RulesAndActions;
using Elements;
using Csemi;
using DepAnalysis;
using Ctoker;

namespace Parsers
{
  /////////////////////////////////////////////////////////
  // rule-based parser used for code analysis

  public class Parser
  {
    private List<IRule> Rules;

    public Parser()
    {
      Rules = new List<IRule>();
    }
    public void add(IRule rule)
    {
      Rules.Add(rule);
    }
    public void parse(Collections.ITokenCollection semi)
    {
      // Note: rule returns true to tell parser to stop
      //       processing the current semiExp
      
      Display.displaySemiString(semi.ToString());

      foreach (IRule rule in Rules)
      {
        if (rule.test(semi))
          break;
      }
    }
  }

  public class TestParser
  {
    //----< process commandline to get file references >-----------------

    public static List<string> ProcessCommandline(string[] args)
    {
      List<string> files = new List<string>();
      if (args.Length == 0)
      {
        Console.Write("\n  Please enter file(s) to analyze\n\n");
        return files;
      }
      string path = args[0];
      path = Path.GetFullPath(path);
      for (int i = 1; i < args.Length; ++i)
      {
        string filename = Path.GetFileName(args[i]);
        files.AddRange(Directory.GetFiles(path, filename));
      }
      return files;
    }

    public static void ShowCommandLine(string[] args)
    {
      Console.Write("\n  Commandline args are:\n  ");
      foreach (string arg in args)
      {
        Console.Write("  {0}", arg);
      }
      Console.Write("\n  current directory: {0}", System.IO.Directory.GetCurrentDirectory());
      Console.Write("\n");
    }

        //----< Test Stub >--------------------------------------------------

#if (TEST_PARSER)

        static void Main(string[] args)
        {
            Console.Write("\n  Demonstrating Parser");
            Console.Write("\n ======================\n");

            ShowCommandLine(args);

            List<string> files = TestParser.ProcessCommandline(args);
            TypeTable.TypeTable types = new TypeTable.TypeTable();
            foreach (string file in files)
            {
                Console.Write("\n  Processing file {0}\n", System.IO.Path.GetFileName(file));

                ITokenCollection semi = Factory.create();
                //semi.displayNewLines = false;
                if (!semi.open(file as string))
                {
                    Console.Write("\n  Can't open {0}\n\n", args[0]);
                    return;
                }

                Console.Write("\n  Type  Analysis");
                Console.Write("\n --------------------------------------------------------------------");

                BuildCodeAnalyzer builder = new BuildCodeAnalyzer(semi);
                Parser parser = builder.build();

                try
                {
                    while (semi.get().Count > 0)
                        parser.parse(semi);
                }
                catch (Exception ex)
                {
                    Console.Write("\n\n  {0}\n", ex.Message);
                }
                Repository rep = Repository.getInstance();
                List<Elem> table = rep.locations;
                Display.showMetricsTable(table);
                Console.Write("\n --------------------------------------------------------------------");
                String name = " ";
                foreach (Elem e in table)
                {
                    if (e.type == "namespace")
                    {
                        name = e.name;
                    }
                    else
                    {
                        if (e.type == "Alias" || e.type == "function") continue;
                        types.add(e.type, e.name, System.IO.Path.GetFileName(file), name);
                    }
                    Console.Write("\n");
                }
                semi.close();
            }
            /*
            Console.Write("\n\n");
            Console.Write("\n  TypeTable");
            Console.Write("\n ============================");
            Console.Write("\n  Type_Demo");
            Console.Write("\n   [TypeName, Filename, Namespace]");
            Console.Write("\n ============================");
            types.show();

            Console.Write("\n  Depedency Analysis");
            Console.Write("\n =========================================");
            DepAnalysis.DAnalysiss ana = new DepAnalysis.DAnalysiss();
            foreach (string file in files)
            {
                ITokenCollection semi = Factory.create();
                if (!semi.open(file as string))
                {
                    Console.Write("\n  Can't open {0}\n\n", args[0]);
                    return;
                }
                while (! semi.isDone())
                {
                  semi.get();
                  ana.analysis(semi, types, System.IO.Path.GetFileName(file));
                }

            }
            ana.show();
            */
            Console.ReadKey();
        }
#endif
  }
}
