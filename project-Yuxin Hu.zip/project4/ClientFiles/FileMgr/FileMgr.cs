///////////////////////////////////////////////////////////////////////
// NavigateWithDelegates.cs - Navigates a Directory Subtree,         //
// Language:    C#, 2008, .Net Framework 4.0                         //
// Application: Demonstration for CSE681, Project #3, Fall 2018      //
// Author:      Yuxin Hu, Syracuse University                        //
///////////////////////////////////////////////////////////////////////
/*
 *  Module Operations:
 *  ==================
 *  Recursively displays the contents of a directory tree
 *  rooted at a specified path, with specified file pattern.
 *  
 *  Provide the all .cs file path to the tester package.
 * 
 *  Maintenance History:
 *  ====================
 *  ver 1.3 :
 *  - added function show() to output all the file path collected in this package
 *  ver 1.2 :
 *  - added multiple pattern handling and modified comments
 *  ver 1.1 :
 *  - modified the initial function go()
 *  ver 1.0 :
 *  - first release
 */
//
using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Navigator;

namespace FileUtilities
{
    public enum FileMgrType { Local, Remote }

    ///////////////////////////////////////////////////////////////////
    // NavigatorClient uses only this interface and factory

    public interface IFileMgr
    {
        IEnumerable<string> getFiles();
        IEnumerable<string> getcsFiles();
        IEnumerable<string> getDirs();
        IEnumerable<string> getallfiles();
        bool setDir(string dir);
        Stack<string> pathStack { get; set; }
        string currentPath { get; set; }
    }

    public class FileMgrFactory
    {
        static public IFileMgr create(FileMgrType type)
        {
            if (type == FileMgrType.Local)
                return new LocalFileMgr();
            else
                return null;  // eventually will have remote file Mgr
        }
    }

    public class LocalFileMgr : IFileMgr
    {
        public string currentPath { get; set; } = "";
        public Stack<string> pathStack { get; set; } = new Stack<string>();
        public LocalFileMgr()
        {
            pathStack.Push(currentPath);  // stack is used to move to parent directory
        }
        //----< get names of all files in current directory >------------
        public IEnumerable<string> getFiles()
        {
            List<string> files = new List<string>();
            string path = Path.Combine(Navigator.Environment.root, currentPath);
            string absPath = Path.GetFullPath(path);
            files = Directory.GetFiles(path).ToList<string>();
            for (int i = 0; i < files.Count(); ++i)
            {
                files[i] = Path.Combine(currentPath, Path.GetFileName(files[i]));
            }
            return files;
        }
        public IEnumerable<string> getcsFiles()
        {
            List<string> files = new List<string>();
            List<string> csFiles = new List<string>();
            List<string> intercs = new List<string>();
            string path = Path.Combine(Navigator.Environment.root, currentPath);
            string absPath = Path.GetFullPath(path);
            files = Directory.GetFiles(path).ToList<string>();
            for (int i = 0; i < files.Count(); ++i)
            {
                files[i] = Path.Combine(currentPath, Path.GetFileName(files[i]));
            }
            foreach (var file in files)
            {
                if (file.Contains(".cs"))
                    csFiles.Add(file);
            }
            foreach (var ala in csFiles)
            {
                string ex = Path.GetExtension(ala);
                if (ex == ".cs")
                {
                    intercs.Add(ala);
                }
                csFiles = intercs;
            }
            return csFiles;
        }
        //----< get names of all subdirectories in current directory >---
        public IEnumerable<string> getDirs()
        {
            List<string> dirs = new List<string>();
            string path = Path.Combine(Navigator.Environment.root, currentPath);
            dirs = Directory.GetDirectories(path).ToList<string>();
            for (int i = 0; i < dirs.Count(); ++i)
            {
                string dirName = new DirectoryInfo(dirs[i]).Name;
                dirs[i] = Path.Combine(currentPath, dirName);
            }
            return dirs;
        }
        public IEnumerable<string> getallfiles()
        {
            List<string> files = new List<string>();
            List<string> dirs = new List<string>();
            string path = Path.Combine(Navigator.Environment.root, currentPath);
            files = Directory.GetFiles(path).ToList<string>();
            for (int i = 0; i < files.Count(); ++i)
            {
                files[i] = Path.Combine(currentPath, Path.GetFileName(files[i]));
            }
            dirs = Directory.GetDirectories(path).ToList<string>();
            while (dirs.Count != 0)
            {
                dirs = Directory.GetDirectories(path).ToList<string>();
            }
            return files;
        }
        //----< sets value of current directory - not used >-------------
        public bool setDir(string dir)
        {
            if (!Directory.Exists(dir))
                return false;
            currentPath = dir;
            return true;
        }
    }
    ///////////////////////////////////////////////////////////////////
    // Navigate class
    // - uses public event properties to avoid binding directly
    //   to application processing
    public class Navigate
    {
        // define public delegate property with private backing store
        private List<string> patterns_ = new List<string>();

        public Navigate()
        {
            patterns_.Add("*.*");
        }

        public void Add(string pattern)
        {
            if (patterns_.Count == 1 && patterns_[0] == "*.*")
            {
                patterns_.Clear();
            }
            patterns_.Add(pattern);
        }
        ///////////////////////
        // The go function has no application specific code.
        // It just invokes its event delegate to notify clients.
        // The clients take care of all the application specific stuff.
        public string[] enrtydirectory(string path)
        {
            return Directory.GetDirectories(path);
        }
        public string[] go()
        {
            string path;
            path = Path.GetFullPath("../../../");
            string[] alldirectory = enrtydirectory(path);
            List<string> tempdirectory = new List<string>();
            List<string> allFiles = new List<string>();
            List<string> intercs = new List<string>();
            List<string> finalcs = new List<string>();
            foreach (var ele in alldirectory)
            {
                string[] a = Directory.GetFileSystemEntries(ele);
                foreach (var file in a)
                {
                    if (file.Contains(".cs"))
                        allFiles.Add(file);
                }
            }

            foreach (var ala in allFiles)
            {
                string ex = Path.GetExtension(ala);
                if (ex == ".cs")
                {
                    intercs.Add(ala);
                }
                allFiles = intercs;
            }
            return allFiles.ToArray();
        }
        public void show()
        {
            Console.Write("\n The Table shows all path of .cs files that used in this project  ");
            Console.Write("\n ================================================================ ");
            string[] showFiles = go();
            foreach (string show in showFiles)
            {
                Console.Write("\n {0}", show);
            }
            Console.Write("\n ================================================================ ");
            Console.Write("\n");
            Console.Write("\n");
        }
  }
    class Test
    {
        [STAThread]
        static void Main(string[] args)
        {

            // path = Directory.GetCurrentDirectory();
            Navigate nav = new Navigate();
            nav.go();

            Console.Write("\n\n");
            Console.ReadKey();
        }
    }
}
