﻿///////////////////////////////////////////////////////////////////////
// Test.cs - Test and analyze the project                            //
// Language:    C#, 2008, .Net Framework 4.0                         //
// Application: Demonstration for CSE681, Project #3, Fall 2018      //
// Author:      Yuxin Hu, Syracuse University                        //
///////////////////////////////////////////////////////////////////////
/*
 * Package Operations
 * ==================
/*
 *   This test file uses all these files and Main funtion to complete the Project#3 requirements.
 *   includes Type Analysis TypeTable Dependmency Analysis and Strongcomponent table.
 *   
 *   DAnalysiss.cs
 *   Display.cs
 *   Element.cs
 *   FileMgr.cs
 *   IRuleandAction.cs
 *   Parser.cs
 *   RulesAndActions.cs
 *   ScopeStack.cs
 *   ITokenCollection.cs
 *   Semi.cs
 *   Strongcomponent.cs
 *   Test.cs
 *   Toker.cs
 *   TypeTable.cs
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;
using Parsers;
using Collections;
using RulesAndActions;
using Elements;
using Csemi;
using CodeDisplay;
using CsGraph;
using FileUtilities;
using TypeTable;

namespace Tester
{
    public class server_test
    {
        public static TypeTable.TypeTable run_typetable(string[] args)
        {
            TypeTable.TypeTable types = new TypeTable.TypeTable();
            foreach (string file in args)
            {
                ITokenCollection semi = Factory.create();
                //semi.displayNewLines = false;
                string path = Path.Combine(Navigator.Environment.root, file);
                if (!semi.open(path as string))
                {
                    Console.Write("\n  Can't open {0}\n\n", args[0]);
                    return types;
                }
                BuildCodeAnalyzer builder = new BuildCodeAnalyzer(semi);
                Parser parser = builder.build();
                try
                {
                    while (semi.get().Count > 0)
                        parser.parse(semi);
                }
                catch (Exception ex)
                {
                    Console.Write("\n  {0}\n", ex.Message);
                }
                Repository rep = Repository.getInstance();
                List<Elem> table = rep.locations;
                String name = " ";
                foreach (Elem e in table)
                {
                    if (e.type == "namespace")
                    {
                        name = e.name;
                    }
                    else
                    {
                        if (e.type == "Alias" || e.type == "function") continue;
                        types.add(e.type, e.name, System.IO.Path.GetFileName(file), name);
                    }
                }
                semi.close();
            }
            return types;
        }
        public static DepAnalysis.DAnalysiss run_depanalysis(string[] args)
        {
            TypeTable.TypeTable types = new TypeTable.TypeTable();
            DepAnalysis.DAnalysiss ana = new DepAnalysis.DAnalysiss();
            string[] files;
            FileUtilities.Navigate navigate = new FileUtilities.Navigate();
            files = navigate.go();
            foreach (string file in files)
            {
                ITokenCollection semi = Factory.create();
                //semi.displayNewLines = false;
                if (!semi.open(file as string))
                {
                    Console.Write("\n  Can't open {0}\n\n", args[0]);
                    return ana;
                }

                BuildCodeAnalyzer builder = new BuildCodeAnalyzer(semi);
                Parser parser = builder.build();

                try
                {
                    while (semi.get().Count > 0)
                        parser.parse(semi);
                }
                catch (Exception ex)
                {
                    Console.Write("\n\n  {0}\n", ex.Message);
                }
                Repository rep = Repository.getInstance();
                List<Elem> table = rep.locations;
                String name = " ";
                foreach (Elem e in table)
                {
                    if (e.type == "namespace")
                    {
                        name = e.name;
                    }
                    else
                    {
                        if (e.type == "Alias" || e.type == "function") continue;
                        types.add(e.type, e.name, System.IO.Path.GetFileName(file), name);
                    }
                }
                semi.close();
            }
            foreach (string file in args)
            {
                ITokenCollection semi = Factory.create();
                string path = Path.Combine(Navigator.Environment.root, file);
                if (!semi.open(path as string))
                {
                    Console.Write("\n  Can't open {0}\n\n", args[0]);
                    return ana;
                }
                while (!semi.isDone())
                {
                    semi.get();
                    ana.analysis(semi, types, System.IO.Path.GetFileName(file));
                }

            }
            return ana;
        }
    }

    class Test
    {
        static void Main(string[] args)
        {
            string[] files;
            FileUtilities.Navigate navigate = new FileUtilities.Navigate();
            files = navigate.go();
            navigate.show();
            TypeTable.TypeTable types = new TypeTable.TypeTable();
            foreach (string file in files)
            {
                Console.Write("\n  Processing file {0}\n", System.IO.Path.GetFileName(file));
                ITokenCollection semi = Factory.create();
                //semi.displayNewLines = false;
                if (!semi.open(file as string))
                {
                    Console.Write("\n  Can't open {0}\n\n", args[0]);
                    return;
                }

                Console.Write("\n  Type  Analysis");
                Console.Write("\n --------------------------------------------------------------------");

                BuildCodeAnalyzer builder = new BuildCodeAnalyzer(semi);
                Parser parser = builder.build();

                try
                {
                    while (semi.get().Count > 0)
                        parser.parse(semi);
                }
                catch (Exception ex)
                {
                    Console.Write("\n\n  {0}\n", ex.Message);
                }
                Repository rep = Repository.getInstance();
                List<Elem> table = rep.locations;
                Display.showMetricsTable(table);
                Console.Write("\n --------------------------------------------------------------------");
                String name = " ";
                foreach (Elem e in table)
                {
                    if (e.type == "namespace")
                    {
                        name = e.name;
                    }
                    else
                    {
                        if (e.type == "Alias" || e.type == "function") continue;
                        types.add(e.type, e.name, System.IO.Path.GetFileName(file), name);
                    }
                    Console.Write("\n");
                }
                semi.close();
            }
            Console.Write("\n\n");
            Console.Write("\n  TypeTable");
            Console.Write("\n =========================================");
            Console.Write("\n  Type_Demo");
            Console.Write("\n   [TypeName, Filename, Namespace]");
            Console.Write("\n =========================================");
            types.show();

            Console.Write("\n  Depedency Analysis");
            Console.Write("\n =========================================");
            DepAnalysis.DAnalysiss ana = new DepAnalysis.DAnalysiss();
            foreach (string file in files)
            {
                ITokenCollection semi = Factory.create();
                if (!semi.open(file as string))
                {
                    Console.Write("\n  Can't open {0}\n\n", args[0]);
                    return;
                }
                while (!semi.isDone())
                {
                    semi.get();
                    ana.analysis(semi, types, System.IO.Path.GetFileName(file));
                }
            }
            ana.show();
            CsGraph.setGraph setGraph = new CsGraph.setGraph();
            setGraph.createGraph(ana);
            Console.ReadKey();
        }
    }
}
