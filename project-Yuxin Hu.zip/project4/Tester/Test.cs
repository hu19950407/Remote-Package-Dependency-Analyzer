﻿///////////////////////////////////////////////////////////////////////
// Test.cs - Test and analyze the project                            //
// Language:    C#, 2008, .Net Framework 4.0                         //
// Application: Demonstration for CSE681, Project #3, Fall 2018      //
// Author:      Yuxin Hu, Syracuse University                        //
///////////////////////////////////////////////////////////////////////
/*
 * Package Operations
 * ==================
/*
 *   This test file uses all these files and Main funtion to complete the Project#3 requirements.
 *   includes Type Analysis TypeTable Dependmency Analysis and Strongcomponent table.
 *   
 *   DAnalysiss.cs
 *   Display.cs
 *   Element.cs
 *   FileMgr.cs
 *   IRuleandAction.cs
 *   Parser.cs
 *   RulesAndActions.cs
 *   ScopeStack.cs
 *   ITokenCollection.cs
 *   Semi.cs
 *   Strongcomponent.cs
 *   Test.cs
 *   Toker.cs
 *   TypeTable.cs
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;
using Parsers;
using Collections;
using RulesAndActions;
using Elements;
using Csemi;
using CodeDisplay;
using CsGraph;
using FileUtilities;
using TypeTable;

namespace Tester
{
    public class server_test
    {
        public static TypeTable.TypeTable run_typetable(string[] args)
        {
            TypeTable.TypeTable types = new TypeTable.TypeTable();
            foreach (string file in args)
            {
                ITokenCollection semi = Factory.create();
                string path = Path.Combine(Navigator.Environment.root, file);
                if (!semi.open(path as string))
                {
                    Console.Write("\n  Can't open {0}\n\n", args[0]);
                    return types;
                }
                BuildCodeAnalyzer builder = new BuildCodeAnalyzer(semi);
                Parser parser = builder.build();
                try
                {
                    while (semi.get().Count > 0)
                        parser.parse(semi);
                }
                catch (Exception ex)
                {
                    Console.Write("\n  {0}\n", ex.Message);
                }
                Repository rep = Repository.getInstance();
                List<Elem> table = rep.locations;
                String name = " ";
                foreach (Elem e in table)
                {
                    if (e.type == "namespace")
                    {
                        name = e.name;
                    }
                    else
                    {
                        if (e.type == "Alias" || e.type == "function") continue;
                        types.add(e.type, e.name, System.IO.Path.GetFileName(file), name);
                    }
                }
                semi.close();
            }
            return types;
        }
        public static DepAnalysis.DAnalysiss run_depanalysis(string[] args)
        {
            TypeTable.TypeTable types = new TypeTable.TypeTable();
            DepAnalysis.DAnalysiss ana = new DepAnalysis.DAnalysiss();
            List<string> files = new List<string>();
            FileUtilities.LocalFileMgr navigate = new FileUtilities.LocalFileMgr();
            FileUtilities.Navigate pathway = new FileUtilities.Navigate();
            string path1 = Path.GetFullPath(Navigator.Environment.root);
            files = pathway.FindFile(path1);
            types = run_typetable(files.ToArray());
            foreach (string file in args)
            {
                ITokenCollection semi = Factory.create();
                string path = Path.Combine(Navigator.Environment.root, file);
                if (!semi.open(path as string))
                {
                    Console.Write("\n  Can't open {0}\n\n", path);
                    return ana;
                }
                while (!semi.isDone())
                {
                    semi.get();
                    ana.analysis(semi, types, System.IO.Path.GetFileName(file));
                }
            }
            return ana;
        }
        public static List<string> run_strongcomponent(string[] args)
        {
            CsGraph.setGraph setGraph = new CsGraph.setGraph();
            DepAnalysis.DAnalysiss ana = new DepAnalysis.DAnalysiss();
            List<string> files = new List<string>();
            List<string> sc = new List<string>();
            List<string> vs = new List<string>();
            List<string> ds = new List<string>();
            string S1 = "";
            string S2 = "";
            FileUtilities.LocalFileMgr navigate = new FileUtilities.LocalFileMgr();
            FileUtilities.Navigate pathway = new FileUtilities.Navigate();
            string path1 = Path.GetFullPath(Navigator.Environment.root);
            files = pathway.FindFile(path1);
            ana = run_depanalysis(files.ToArray());
            sc = setGraph.createGraph(ana);
            foreach(var a in sc)
            {
                if (a == "StrongComponent: ")
                {
                    vs.Add(S1);
                    S1 = "";
                }
                else S1 = S1 + " " + a;
            }
            vs.Add(S1);
            vs.Remove("");
            foreach(var s in vs)
            {
                if (!ds.Contains(s))
                    ds.Add(s);
            }
            sc.Clear();
            foreach (var d in ds)
            {
                S2 = "StrongComponent: " + d;
                sc.Add(S2);
            }
            return sc;
        }
    }

    class Test
    {
        static void Main(string[] args)
        {
            string[] files;
            FileUtilities.Navigate navigate = new FileUtilities.Navigate();
            files = navigate.go();
            navigate.show();
            TypeTable.TypeTable types = new TypeTable.TypeTable();
            foreach (string file in files)
            {
                Console.Write("\n  Processing file {0}\n", System.IO.Path.GetFileName(file));
                ITokenCollection semi = Factory.create();               //semi.displayNewLines = false;
                if (!semi.open(file as string))
                {
                    Console.Write("\n  Can't open {0}\n\n", args[0]);
                    return;
                }
                BuildCodeAnalyzer builder = new BuildCodeAnalyzer(semi);
                Parser parser = builder.build();
                try
                {
                    while (semi.get().Count > 0)
                        parser.parse(semi);
                }
                catch (Exception ex)
                {
                    Console.Write("\n\n  {0}\n", ex.Message);
                }
                Repository rep = Repository.getInstance();
                List<Elem> table = rep.locations;
                Display.showMetricsTable(table);
                String name = " ";
                foreach (Elem e in table)
                {
                    if (e.type == "namespace")
                    {
                        name = e.name;
                    }
                    else
                    {
                        if (e.type == "Alias" || e.type == "function") continue;
                        types.add(e.type, e.name, System.IO.Path.GetFileName(file), name);
                    }
                    Console.Write("\n");
                }
                semi.close();
            }
            Console.Write("\n\n  TypeTable\n");
            types.show();
            Console.Write("\n  Depedency Analysis\n");
            DepAnalysis.DAnalysiss ana = new DepAnalysis.DAnalysiss();
            foreach (string file in files)
            {
                ITokenCollection semi = Factory.create();
                if (!semi.open(file as string))
                {
                    Console.Write("\n  Can't open {0}\n\n", args[0]);
                    return;
                }
                while (!semi.isDone())
                {
                    semi.get();
                    ana.analysis(semi, types, System.IO.Path.GetFileName(file));
                }
            }
            ana.show();
            CsGraph.setGraph setGraph = new CsGraph.setGraph();
            setGraph.createGraph(ana);
            Console.ReadKey();
        }
    }
}
